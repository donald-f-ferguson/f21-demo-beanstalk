# E6156 - Topics in SW Engineering: Cloud Computing

Sample AWS Elastic Beanstalk application

Zipping on Windows is a pain in the neck. Use.

zip -r -X Archive.zip *
